Shader "Custom/HolographicShader"
{
    Properties
    {
        _Color ("Main Color", Color) = (0.5, 0.8, 1.0, 0.7)
        _RimPower ("Rim Power", Range(0.1, 8.0)) = 3.0
        _RimColor ("Rim Color", Color) = (0.5, 0.8, 1.0, 1.0)
        _ScanLineSpeed ("Scan Line Speed", Range(0, 5)) = 2.0
        _FresnelPower ("Fresnel Power", Range(0.1, 5.0)) = 2.0
        _Alpha ("Alpha", Range(0, 1)) = 0.7
    }
    
    SubShader
    {
        Tags { "Queue"="Transparent" "RenderType"="Transparent" }
        LOD 200
        
        Blend SrcAlpha OneMinusSrcAlpha
        ZWrite Off
        
        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"
            
            float4 _Color;
            float _RimPower;
            float4 _RimColor;
            float _ScanLineSpeed;
            float _FresnelPower;
            float _Alpha;
            
            struct appdata
            {
                float4 vertex : POSITION;
                float3 normal : NORMAL;
            };
            
            struct v2f
            {
                float4 pos : SV_POSITION;
                float3 worldNormal : TEXCOORD0;
                float3 worldPos : TEXCOORD1;
            };
            
            v2f vert(appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.worldNormal = UnityObjectToWorldNormal(v.normal);
                o.worldPos = mul(unity_ObjectToWorld, v.vertex).xyz;
                return o;
            }
            
            fixed4 frag(v2f i) : SV_Target
            {
                // Fresnel effect
                float3 viewDir = normalize(_WorldSpaceCameraPos - i.worldPos);
                float3 normal = normalize(i.worldNormal);
                float fresnel = pow(1.0 - saturate(dot(viewDir, normal)), _FresnelPower);
                
                // Rim lighting
                float rim = pow(1.0 - saturate(dot(viewDir, normal)), _RimPower);
                float4 rimColor = _RimColor * rim;
                
                // Scan lines
                float scanLine = sin(i.worldPos.y * 10.0 + _Time.y * _ScanLineSpeed);
                scanLine = smoothstep(0.3, 0.7, scanLine);
                
                // Combine effects
                float4 finalColor = _Color + rimColor;
                finalColor.rgb += scanLine * 0.2;
                finalColor.a = _Alpha * fresnel;
                
                return finalColor;
            }
            ENDCG
        }
    }
    
    FallBack "Transparent/Diffuse"
}
