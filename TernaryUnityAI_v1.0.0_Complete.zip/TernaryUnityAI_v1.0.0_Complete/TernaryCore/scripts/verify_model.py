"""
verify_model.py - ONNX Model Verification Tool
Validates model integrity and compatibility
"""

import sys
import onnx
import onnxruntime as ort
import numpy as np
from pathlib import Path
import hashlib

def verify_onnx_model(model_path: str) -> bool:
    """
    Comprehensive ONNX model verification
    
    Args:
        model_path: Path to ONNX model
    
    Returns:
        True if all checks pass, False otherwise
    """
    model_path = Path(model_path)
    
    if not model_path.exists():
        print(f"✗ Model file not found: {model_path}")
        return False
    
    print(f"\n{'='*60}")
    print(f"Verifying: {model_path.name}")
    print(f"{'='*60}\n")
    
    # Check 1: File size
    file_size = model_path.stat().st_size
    print(f"[1/6] File size: {file_size / 1_000_000:.2f} MB")
    
    if file_size < 1_000_000:  # Less than 1 MB
        print("⚠ Warning: File size unusually small")
    
    # Check 2: SHA-256 checksum
    print(f"\n[2/6] Computing SHA-256 checksum...")
    sha256_hash = hashlib.sha256()
    with open(model_path, 'rb') as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    
    checksum = sha256_hash.hexdigest()
    print(f"✓ SHA-256: {checksum}")
    
    # Check 3: ONNX structure validation
    print(f"\n[3/6] Validating ONNX structure...")
    try:
        model = onnx.load(str(model_path))
        onnx.checker.check_model(model)
        print("✓ ONNX structure valid")
    except Exception as e:
        print(f"✗ ONNX validation failed: {e}")
        return False
    
    # Check 4: Model metadata
    print(f"\n[4/6] Model metadata:")
    print(f"  IR version: {model.ir_version}")
    print(f"  Producer: {model.producer_name} {model.producer_version}")
    print(f"  Graph name: {model.graph.name}")
    
    # Check 5: Input/output shapes
    print(f"\n[5/6] Input/output specifications:")
    
    for input_tensor in model.graph.input:
        shape = [dim.dim_value for dim in input_tensor.type.tensor_type.shape.dim]
        print(f"  Input '{input_tensor.name}': {shape}")
    
    for output_tensor in model.graph.output:
        shape = [dim.dim_value for dim in output_tensor.type.tensor_type.shape.dim]
        print(f"  Output '{output_tensor.name}': {shape}")
    
    # Check 6: ONNX Runtime compatibility
    print(f"\n[6/6] Testing ONNX Runtime compatibility...")
    
    try:
        # Get available providers
        providers = ort.get_available_providers()
        print(f"  Available providers: {', '.join(providers)}")
        
        # Try to create session with DirectML (if available)
        if 'DmlExecutionProvider' in providers:
            print("  Testing DirectML provider...")
            session = ort.InferenceSession(
                str(model_path),
                providers=['DmlExecutionProvider']
            )
            print("  ✓ DirectML compatible")
        
        # Fallback to CPU
        print("  Testing CPU provider...")
        session = ort.InferenceSession(
            str(model_path),
            providers=['CPUExecutionProvider']
        )
        print("  ✓ CPU compatible")
        
        # Get input details
        input_name = session.get_inputs()[0].name
        input_shape = session.get_inputs()[0].shape
        input_type = session.get_inputs()[0].type
        
        print(f"\n  Session input: {input_name}")
        print(f"  Shape: {input_shape}")
        print(f"  Type: {input_type}")
        
        # Test inference with dummy data
        print("\n  Running test inference...")
        dummy_input = np.random.randn(1, 3, 518, 518).astype(np.float32)
        output = session.run(None, {input_name: dummy_input})
        
        print(f"  ✓ Inference successful")
        print(f"  Output shape: {output[0].shape}")
        
    except Exception as e:
        print(f"  ✗ Runtime test failed: {e}")
        return False
    
    # All checks passed
    print(f"\n{'='*60}")
    print("✓ All verification checks passed!")
    print(f"{'='*60}\n")
    
    return True

def main():
    if len(sys.argv) < 2:
        print("Usage: python verify_model.py <path_to_model.onnx>")
        print("\nExample:")
        print("  python verify_model.py Models/depth_anything_v2_vits.onnx")
        sys.exit(1)
    
    model_path = sys.argv[1]
    
    success = verify_onnx_model(model_path)
    
    if success:
        print("Model is ready to use!")
        print("\nNext steps:")
        print("1. Test with real image: python tests/test_depth_model.py")
        print("2. Start Unity bridge: python src/bridge/unity_bridge.py")
        sys.exit(0)
    else:
        print("\n✗ Model verification failed")
        print("Please re-download the model or check for corruption")
        sys.exit(1)

if __name__ == '__main__':
    main()
