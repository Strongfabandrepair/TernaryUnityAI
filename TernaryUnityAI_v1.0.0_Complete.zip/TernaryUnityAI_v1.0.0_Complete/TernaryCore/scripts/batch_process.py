"""
batch_process.py - Batch Image Processing Script
Process multiple images in parallel
"""

import os
import sys
import cv2
import numpy as np
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
import argparse
import json

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.ai.depth_model import DepthEstimator
from src.ai.pointcloud import DepthTo3DPipeline

def process_single_image(
    image_path: Path,
    output_dir: Path,
    estimator: DepthEstimator,
    pipeline: DepthTo3DPipeline,
    save_depth: bool = True,
    save_pointcloud: bool = True,
    save_mesh: bool = True
) -> dict:
    """
    Process a single image through the full pipeline
    
    Args:
        image_path: Input image path
        output_dir: Output directory
        estimator: Depth estimator instance
        pipeline: 3D pipeline instance
        save_depth: Save depth visualization
        save_pointcloud: Save point cloud
        save_mesh: Save mesh
    
    Returns:
        Results dictionary
    """
    try:
        # Load image
        image = cv2.imread(str(image_path))
        if image is None:
            return {'status': 'error', 'message': f'Failed to load image: {image_path}'}
        
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Get filename without extension
        filename = image_path.stem
        
        # Depth estimation
        depth_map = estimator.predict(image_rgb)
        
        results = {
            'status': 'success',
            'input': str(image_path),
            'outputs': {}
        }
        
        # Save depth visualization
        if save_depth:
            depth_path = output_dir / f"{filename}_depth.png"
            estimator.save_depth_visualization(depth_map, str(depth_path))
            results['outputs']['depth'] = str(depth_path)
        
        # 3D reconstruction
        if save_pointcloud or save_mesh:
            pipeline_results = pipeline.process(
                depth_map,
                image_rgb,
                str(output_dir),
                filename
            )
            
            if save_pointcloud:
                results['outputs']['pointcloud'] = pipeline_results['pointcloud']
            
            if save_mesh:
                results['outputs']['mesh'] = pipeline_results['mesh']
        
        return results
        
    except Exception as e:
        return {'status': 'error', 'message': str(e), 'input': str(image_path)}

def batch_process(
    input_dir: str,
    output_dir: str,
    model_path: str,
    max_workers: int = 4,
    save_depth: bool = True,
    save_pointcloud: bool = True,
    save_mesh: bool = True,
    extensions: list = ['.jpg', '.jpeg', '.png']
) -> dict:
    """
    Process multiple images in parallel
    
    Args:
        input_dir: Input directory containing images
        output_dir: Output directory
        model_path: Path to ONNX model
        max_workers: Number of parallel workers
        save_depth: Save depth visualizations
        save_pointcloud: Save point clouds
        save_mesh: Save meshes
        extensions: Image file extensions to process
    
    Returns:
        Summary dictionary
    """
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Find all images
    image_files = []
    for ext in extensions:
        image_files.extend(input_dir.glob(f"*{ext}"))
        image_files.extend(input_dir.glob(f"*{ext.upper()}"))
    
    if not image_files:
        print(f"No images found in {input_dir}")
        return {'status': 'error', 'message': 'No images found'}
    
    print(f"Found {len(image_files)} images to process")
    
    # Initialize models (shared across threads)
    print("Initializing AI models...")
    estimator = DepthEstimator(model_path, use_npu=True)
    pipeline = DepthTo3DPipeline(focal_length=525.0, reconstruction_method="poisson")
    
    # Process images in parallel
    results = []
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks
        futures = {
            executor.submit(
                process_single_image,
                image_path,
                output_dir,
                estimator,
                pipeline,
                save_depth,
                save_pointcloud,
                save_mesh
            ): image_path
            for image_path in image_files
        }
        
        # Process with progress bar
        with tqdm(total=len(image_files), desc="Processing images") as pbar:
            for future in as_completed(futures):
                result = future.result()
                results.append(result)
                pbar.update(1)
                
                # Print status
                if result['status'] == 'success':
                    pbar.set_postfix({'status': '✓', 'file': Path(result['input']).name})
                else:
                    pbar.set_postfix({'status': '✗', 'error': result.get('message', 'Unknown error')})
    
    # Generate summary
    successful = sum(1 for r in results if r['status'] == 'success')
    failed = len(results) - successful
    
    summary = {
        'total': len(results),
        'successful': successful,
        'failed': failed,
        'output_dir': str(output_dir),
        'results': results
    }
    
    # Save summary JSON
    summary_path = output_dir / 'batch_summary.json'
    with open(summary_path, 'w') as f:
        json.dump(summary, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"Batch processing complete!")
    print(f"  Total: {len(results)}")
    print(f"  Successful: {successful}")
    print(f"  Failed: {failed}")
    print(f"  Summary saved: {summary_path}")
    print(f"{'='*60}\n")
    
    return summary

def main():
    parser = argparse.ArgumentParser(description='Batch process images')
    parser.add_argument('--input', type=str, required=True,
                        help='Input directory containing images')
    parser.add_argument('--output', type=str, required=True,
                        help='Output directory')
    parser.add_argument('--model', type=str, default='Models/depth_anything_v2_vits.onnx',
                        help='Path to ONNX model')
    parser.add_argument('--workers', type=int, default=4,
                        help='Number of parallel workers (default: 4)')
    parser.add_argument('--no-depth', action='store_true',
                        help='Skip depth visualization')
    parser.add_argument('--no-pointcloud', action='store_true',
                        help='Skip point cloud generation')
    parser.add_argument('--no-mesh', action='store_true',
                        help='Skip mesh generation')
    
    args = parser.parse_args()
    
    batch_process(
        input_dir=args.input,
        output_dir=args.output,
        model_path=args.model,
        max_workers=args.workers,
        save_depth=not args.no_depth,
        save_pointcloud=not args.no_pointcloud,
        save_mesh=not args.no_mesh
    )

if __name__ == '__main__':
    main()
