"""
download_models.py - Automated AI Model Downloader
Downloads Depth Anything V2 models from HuggingFace
"""

import os
import sys
import hashlib
import requests
from pathlib import Path
from tqdm import tqdm
import argparse

# Model configurations
MODELS = {
    'depth_anything_v2_vits': {
        'url': 'https://huggingface.co/depth-anything/Depth-Anything-V2-Small/resolve/main/depth_anything_v2_vits.onnx',
        'size': 24_800_000,  # 24.8 MB
        'sha256': 'a3f8b9c2d1e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0',
        'description': 'Depth Anything V2 Small (fastest, recommended)'
    },
    'depth_anything_v2_vitb': {
        'url': 'https://huggingface.co/depth-anything/Depth-Anything-V2-Base/resolve/main/depth_anything_v2_vitb.onnx',
        'size': 97_500_000,  # 97.5 MB
        'sha256': 'b4c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9',
        'description': 'Depth Anything V2 Base (balanced quality/speed)'
    },
    'depth_anything_v2_vitl': {
        'url': 'https://huggingface.co/depth-anything/Depth-Anything-V2-Large/resolve/main/depth_anything_v2_vitl.onnx',
        'size': 335_000_000,  # 335 MB
        'sha256': 'c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6',
        'description': 'Depth Anything V2 Large (best quality, slowest)'
    }
}

def download_file(url: str, output_path: Path, expected_size: int) -> bool:
    """
    Download file with progress bar
    
    Args:
        url: Download URL
        output_path: Output file path
        expected_size: Expected file size in bytes
    
    Returns:
        True if successful, False otherwise
    """
    try:
        print(f"Downloading from: {url}")
        print(f"Saving to: {output_path}")
        
        # Stream download with progress bar
        response = requests.get(url, stream=True, timeout=30)
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        
        if total_size == 0:
            total_size = expected_size
        
        # Create parent directory
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Download with progress bar
        with open(output_path, 'wb') as f:
            with tqdm(total=total_size, unit='B', unit_scale=True, desc=output_path.name) as pbar:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        pbar.update(len(chunk))
        
        print(f"✓ Download complete: {output_path}")
        return True
        
    except requests.exceptions.RequestException as e:
        print(f"✗ Download failed: {e}")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def verify_checksum(file_path: Path, expected_sha256: str) -> bool:
    """
    Verify file SHA-256 checksum
    
    Args:
        file_path: Path to file
        expected_sha256: Expected SHA-256 hash
    
    Returns:
        True if checksum matches, False otherwise
    """
    print(f"Verifying checksum for {file_path.name}...")
    
    sha256_hash = hashlib.sha256()
    
    try:
        with open(file_path, 'rb') as f:
            # Read in chunks to handle large files
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        
        computed_hash = sha256_hash.hexdigest()
        
        # Note: Using placeholder hashes for demonstration
        # In production, replace with actual model hashes
        print(f"Computed SHA-256: {computed_hash}")
        print(f"Expected SHA-256: {expected_sha256}")
        
        # For now, skip verification (placeholder hashes)
        print("⚠ Checksum verification skipped (using placeholder hashes)")
        return True
        
        # Uncomment for production:
        # if computed_hash == expected_sha256:
        #     print("✓ Checksum verified")
        #     return True
        # else:
        #     print("✗ Checksum mismatch!")
        #     return False
        
    except Exception as e:
        print(f"✗ Verification error: {e}")
        return False

def download_model(model_name: str, output_dir: Path, force: bool = False) -> bool:
    """
    Download and verify a model
    
    Args:
        model_name: Model identifier
        output_dir: Output directory
        force: Force re-download if file exists
    
    Returns:
        True if successful, False otherwise
    """
    if model_name not in MODELS:
        print(f"✗ Unknown model: {model_name}")
        print(f"Available models: {', '.join(MODELS.keys())}")
        return False
    
    model_info = MODELS[model_name]
    output_path = output_dir / f"{model_name}.onnx"
    
    print("\n" + "="*60)
    print(f"Model: {model_name}")
    print(f"Description: {model_info['description']}")
    print(f"Size: {model_info['size'] / 1_000_000:.1f} MB")
    print("="*60 + "\n")
    
    # Check if file already exists
    if output_path.exists() and not force:
        print(f"✓ Model already exists: {output_path}")
        
        # Verify existing file
        if output_path.stat().st_size == model_info['size']:
            print("✓ File size matches")
            verify_checksum(output_path, model_info['sha256'])
            return True
        else:
            print("⚠ File size mismatch, re-downloading...")
    
    # Download model
    success = download_file(model_info['url'], output_path, model_info['size'])
    
    if not success:
        return False
    
    # Verify checksum
    if not verify_checksum(output_path, model_info['sha256']):
        print("⚠ Checksum verification failed, but file downloaded")
        print("   You can still use the model, but integrity is not guaranteed")
    
    return True

def main():
    parser = argparse.ArgumentParser(description='Download Depth Anything V2 models')
    parser.add_argument('--model', type=str, default='depth_anything_v2_vits',
                        choices=list(MODELS.keys()) + ['all'],
                        help='Model to download (default: depth_anything_v2_vits)')
    parser.add_argument('--output', type=str, default='Models',
                        help='Output directory (default: Models)')
    parser.add_argument('--force', action='store_true',
                        help='Force re-download if file exists')
    parser.add_argument('--list', action='store_true',
                        help='List available models')
    
    args = parser.parse_args()
    
    # List models
    if args.list:
        print("\nAvailable models:")
        print("="*60)
        for name, info in MODELS.items():
            print(f"\n{name}")
            print(f"  Description: {info['description']}")
            print(f"  Size: {info['size'] / 1_000_000:.1f} MB")
            print(f"  URL: {info['url']}")
        print("\n" + "="*60)
        return
    
    output_dir = Path(args.output)
    
    # Download models
    if args.model == 'all':
        print("\n📥 Downloading all models...")
        success_count = 0
        for model_name in MODELS.keys():
            if download_model(model_name, output_dir, args.force):
                success_count += 1
        
        print("\n" + "="*60)
        print(f"✓ Downloaded {success_count}/{len(MODELS)} models successfully")
        print("="*60)
    else:
        download_model(args.model, output_dir, args.force)
    
    print("\n✓ Download complete!")
    print(f"\nNext steps:")
    print(f"1. Verify installation: python scripts/verify_model.py {output_dir}/{args.model}.onnx")
    print(f"2. Test inference: python tests/test_depth_model.py")
    print(f"3. Start Unity bridge: python src/bridge/unity_bridge.py")

if __name__ == '__main__':
    main()
