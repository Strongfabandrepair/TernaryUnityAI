"""
test_full_pipeline.py - End-to-End Pipeline Test
Tests complete workflow from image to 3D mesh
"""

import sys
import cv2
import numpy as np
from pathlib import Path
import time

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.ai.depth_model import DepthEstimator
from src.ai.pointcloud import DepthTo3DPipeline

def test_pipeline():
    """Run complete pipeline test"""
    
    print("\n" + "="*60)
    print("TernaryUnityAI - Full Pipeline Test")
    print("="*60 + "\n")
    
    # Configuration
    model_path = "Models/depth_anything_v2_vits.onnx"
    test_image = "Examples/example_photos/portrait_01.jpg"
    output_dir = "output/test"
    
    # Check files exist
    if not Path(model_path).exists():
        print(f"✗ Model not found: {model_path}")
        print("Run: python scripts/download_models.py")
        return False
    
    if not Path(test_image).exists():
        print(f"✗ Test image not found: {test_image}")
        print("Please add sample images to Examples/example_photos/")
        return False
    
    # Create output directory
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    # Test 1: Load image
    print("[1/5] Loading test image...")
    image = cv2.imread(test_image)
    if image is None:
        print(f"✗ Failed to load image: {test_image}")
        return False
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    print(f"✓ Image loaded: {image.shape}")
    
    # Test 2: Initialize depth estimator
    print("\n[2/5] Initializing depth estimator...")
    start_time = time.time()
    
    try:
        estimator = DepthEstimator(model_path, use_npu=True)
        init_time = (time.time() - start_time) * 1000
        print(f"✓ Estimator initialized ({init_time:.0f}ms)")
        
        # Print stats
        stats = estimator.get_stats()
        print(f"  Model: {stats['model_path']}")
        print(f"  Input size: {stats['input_size']}")
        print(f"  Providers: {', '.join(stats['providers'])}")
        
    except Exception as e:
        print(f"✗ Initialization failed: {e}")
        return False
    
    # Test 3: Depth estimation
    print("\n[3/5] Running depth estimation...")
    start_time = time.time()
    
    try:
        depth_map = estimator.predict(image_rgb)
        inference_time = (time.time() - start_time) * 1000
        print(f"✓ Depth estimation complete ({inference_time:.0f}ms)")
        print(f"  Depth map shape: {depth_map.shape}")
        print(f"  Depth range: [{depth_map.min():.3f}, {depth_map.max():.3f}]")
        
        # Save depth visualization
        depth_vis_path = Path(output_dir) / "test_depth.png"
        estimator.save_depth_visualization(depth_map, str(depth_vis_path))
        print(f"  Saved: {depth_vis_path}")
        
    except Exception as e:
        print(f"✗ Depth estimation failed: {e}")
        return False
    
    # Test 4: Point cloud generation
    print("\n[4/5] Generating point cloud...")
    start_time = time.time()
    
    try:
        pipeline = DepthTo3DPipeline(
            focal_length=525.0,
            reconstruction_method="poisson"
        )
        
        pcd = pipeline.generator.depth_to_pointcloud(
            depth_map,
            image_rgb,
            downsample=2
        )
        
        pc_time = (time.time() - start_time) * 1000
        print(f"✓ Point cloud generated ({pc_time:.0f}ms)")
        print(f"  Points: {len(pcd.points)}")
        
    except Exception as e:
        print(f"✗ Point cloud generation failed: {e}")
        return False
    
    # Test 5: Mesh reconstruction
    print("\n[5/5] Reconstructing mesh...")
    start_time = time.time()
    
    try:
        results = pipeline.process(
            depth_map,
            image_rgb,
            output_dir,
            "test"
        )
        
        mesh_time = (time.time() - start_time) * 1000
        print(f"✓ Mesh reconstruction complete ({mesh_time:.0f}ms)")
        print(f"  Point cloud: {results['pointcloud']}")
        print(f"  Mesh: {results['mesh']}")
        
    except Exception as e:
        print(f"✗ Mesh reconstruction failed: {e}")
        return False
    
    # Summary
    total_time = inference_time + pc_time + mesh_time
    
    print("\n" + "="*60)
    print("✓ All tests passed!")
    print("="*60)
    print(f"\nPerformance Summary:")
    print(f"  Depth estimation: {inference_time:.0f}ms")
    print(f"  Point cloud:      {pc_time:.0f}ms")
    print(f"  Mesh reconstruction: {mesh_time:.0f}ms")
    print(f"  Total pipeline:   {total_time:.0f}ms ({1000/total_time:.1f} FPS)")
    print(f"\nOutput files:")
    print(f"  {output_dir}/test_depth.png")
    print(f"  {output_dir}/test_pointcloud.ply")
    print(f"  {output_dir}/test_mesh.obj")
    print("\n" + "="*60 + "\n")
    
    return True

if __name__ == '__main__':
    success = test_pipeline()
    sys.exit(0 if success else 1)
